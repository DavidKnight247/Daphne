August 15, 2008

This is a complete EPROM/PROM/microcontroller dump of Cube Quest.

All identified EPROMs, PROMs and microcontrollers in the Cube Quest boardset (including the laser player interface board) have been dumped.

Recent MAME emulation efforts by Philip Bennett (resulting in the need to redump some PROMs) have confirmed this is now a good and complete dump).

Thanks Phil for the fantastic emulation efforts!

If you received a dump and it does not have the 8-15-2008 dated readme, you may have an old (incorrect and incomplete) dump.

The format of the file name for each item is:

BoardName_ChipType.Location

There should be 68 files in this .zip file, broken down as follows:

16 EPROM BD EPROM/PROM files
12 Fill Board EPROM/PROM files
10 Line Drawer EPROM/PROM files
14 Rotate Video Board EPROM/PROM files
14 Mother Sounds EPROM/PROM files
1 laser player interface microcontroller file (Magnavox VC8010)
1 read_me file

Pictures of the PCB used for dumping can be found at http://www.tollianweb.com/uc/Cube_Quest/Cube_Quest_PCB.html
This web site carries individual high resolution pictures of each board in the PCB set.
Click on any picture on the web site to bring up the high resolution picture.
From there, you can right click and save that picture to your local PC.
Then you can zoom in to closely examine the board.

This read_me, this zip file and the dump was done courtesy of Joe Magiera.
It is primarily as backup for Cube Quest owners in case they may experience hardware ROM bit rot.
For anyone that may get or use this file, I would appreciate if you could keep this read_me file along with the ROM files.

If anyone makes any progress disassembling the code, I would appreciate hearing about it.
If anyone has any Cube Quest parts or a whole game (whether or not if it's for sale), I would like to see/hear about it!

If this game gets added to MAME or any other emulator, I would appreciate a ROM dumping and donating credit in the driver.
I would appreciate the opportunity to be a tester for the game as it develops in MAME or any other emulator.

If you have any questions or comments, I can be reached at joemagiera@ameritech.net.

Thanks,

Joe "unknown_comic" Magiera