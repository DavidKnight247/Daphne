Firefox (C) Atari 1984

Rom #	Board Location 	Size
------------------------------
CPU board

101	8A		27128
102	7A		27128
105	4A		27128
106	3A		27128
109	8B/C		27128
110	7B/C		27128
111	6B/C		27128
113	4M		27128
114	4N		27128

Empty Sockets:
6A, 5A, 2A, 1A, 4K/L

Graphics board

115	1C		27128
116	2C		27128
117	3C		27128
118	4C		27128
119	1A		27128
120	2A		27128
121	3A		27128
122	4A		27128
123	5A		27128
124	5C		27128
125	6P		2764

Empty Sockets:
6A, 6C


